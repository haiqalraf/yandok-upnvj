Requirement:
  Composer    https://getcomposer.org/Composer-Setup.exe
  NPM/nodeJs  https://nodejs.org/dist/v14.17.0/node-v14.17.0-x64.msi

Step to run:
  1. Place all file in ../xampp/htdocs/FolderName
  2. open folder directory in cmd or PowerShell
  3. run Apache and MySQL in XAMPP
  4. run "php artisan migrate", "php artisan db:seed"
  5. run "php artisan serve" and let the command run (dont close the cmd or PowerShell windows), this command is used to run application in php development server
  6. access "http://localhost:8000/" in your web browser (its the default domain if you haven't change anything)

note:

login username and password

user/mahasiswa  : 18105

admin           : 18106

password: 123456
