<?php

namespace App\Http\Controllers;

use App\Models\Lainya;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class LainyaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('lainnya.lainnya');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('lainnya.formpengajuan');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'dokumen_dipesan' => 'required',
            'jumlah_dokumen' => 'required|numeric',
            'file' => 'required|file',
        ]);

        if ($request->hasFile('file')) {
            $file = $request->file("file");

            $extension = $file->getClientOriginalExtension();
            $username = auth()->user()->name;
            $date = now("Asia/Jakarta")->format('YmdHis');

            $newName = $date . '_'.Str::slug($request->dokumen_dipesan, '').'_' . $username . '.' . $extension;

            if (!Storage::disk('local')->exists('lainnya/' . $newName)) {
                Storage::disk('local')->put('lainnya/' . $newName, $file->get());
            }

            Lainya::create([
                'nim_pemesan' => auth()->user()->nim,
                'dokumen_dipesan' => $request->dokumen_dipesan,
                'jumlah_dipesan' => $request->jumlah_dokumen,
                'file' => $newName
            ]);
            return redirect('/lainnya');
        } else {
            return back()->with("message", "File Not Found");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Lainya  $lainya
     * @return \Illuminate\Http\Response
     */
    public function show(Lainya $lainya)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Lainya  $lainya
     * @return \Illuminate\Http\Response
     */
    public function edit(/*Lainya $lainya*/)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Lainya  $lainya
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Lainya $lainya)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Lainya  $lainya
     * @return \Illuminate\Http\Response
     */
    public function destroy(Lainya $lainya)
    {
        //
    }
}
