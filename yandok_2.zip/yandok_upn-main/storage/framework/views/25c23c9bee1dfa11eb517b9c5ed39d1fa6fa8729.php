<!doctype html>
<html lang="en">

<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
      integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

   <!-- font google -->
   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet">

   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link href="https://fonts.googleapis.com/css2?family=Lora:wght@400;500;600&display=swap" rel="stylesheet">

   <!-- font awsome -->
   <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css" />

   <!-- Local css -->
   <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
   <!-- header -->
   <div class="container-fluid mb-5 shadow bg-white">
      <div class="col">
         <nav class="navbar navbar-expand-md bg-white">
            <a id="link" class="navbar-brand" href="<?php echo e(route('home')); ?>">
               <img id="logoku" src="img/logoUPN.png" alt="logo" height="63" width="243"
                  class="d-inline-block align-top">
            </a>
            <div class="collapse navbar-collapse">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i></a>
                  </li>
                  <li class="nav-item ml-2">
                     <div class="dropdown ml-2">
                        <a class="nav-link dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">
                           Pesan
                        </a>
                        <div class="dropdown-menu dropdown-menu-sm-right" aria-labelledby="dropdownMenu1">
                           <a href="<?php echo e(route('legalisir.index')); ?>" class="dropdown-item" type="button"
                              style="font-size: small; font-weight: 600;">
                              Legalisir
                           </a>
                           <a href="<?php echo e(route('legalisir.index')); ?>" class="dropdown-item" type="button"
                              style="font-size: small; font-weight: 600;">
                              Surat Keterangan
                           </a>
                           <a href="<?php echo e(route('lainnya')); ?>" class="dropdown-item" type="button"
                              style="font-size: small; font-weight: 600;">
                              Lain-lainya
                           </a>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item ml-2">
                     <a class="nav-link" href="<?php echo e(route('riwayat')); ?>">Riwayat Pemesanan</a>
                  </li>
               </ul>
               <div class="dropdown ml-2">
                  <a class="nav-link dropdown-toggle active" type="button" id="dropdownMenu2" data-toggle="dropdown"
                     aria-haspopup="true" aria-expanded="false">
                     Bantuan
                  </a>
                  <div class="dropdown-menu dropdown-menu-sm-right" aria-labelledby="dropdownMenu2">
                     <a href="{{route('alur')}}" class="dropdown-item on" type="button"
                        style="font-size: small; font-weight: 600;">
                        Alur Proses Pemesanan
                     </a>
                  </div>

               </div>
               <div class=" dropdown">
                  <a style="text-decoration: none;" class="dropdown-toggle text-dark" href="#" data-toggle="dropdown">
                     <img src="img/profil.png" height="64px" width="64px"
                        style="border-radius: 50%; margin-left: 30px;">
                  </a>
                  <div class="dropdown-menu dropdown-menu-sm-right">
                     <ul class="list-unstyled p-3">
                        <li style="font-size: medium; font-weight: 500;">Albet Dwi Pangestu</li>
                        <li style="font-size: small;">18105110XX</li>
                     </ul>
                     <div class="dropdown-divider" style="width: 270px;"></div>
                     <a class="dropdown-item" href="<?php echo e(route('home')); ?>"><i class="fa fa-sign-out"></i> Keluar</a>
                  </div>
               </div>
               <!-- Notif -->
               <div class="dropdown">
                  <a style="text-decoration: none;" class=" text-dark" href="#" data-toggle="dropdown">
                     <img src="img/icon/lonceng.png" alt="notif" class="align-self-center ml-4 mb-2">
                  </a>
                  <div class="dropdown-menu dropdown-menu-sm-right">
                     <a href="{{route('alur')}}" class="dropdown-item" type="button" style="font-size: small;">
                        <p>
                           Pesanan nomor XXX telah diverifikasi/selesai <span class="text-right">
                        </p>
                     </a>
                     <a href="{{route('alur')}}" class="dropdown-item" type="button" style="font-size: small;">
                        <p>
                           Pesanan nomor XXX telah diverifikasi/selesai <span class="text-right">
                        </p>
                     </a>
                     <a href="{{route('alur')}}" class="dropdown-item" type="button" style="font-size: small;">
                        <p>
                           Pesanan nomor XXX telah diverifikasi/selesai <span class="text-right">
                        </p>
                     </a>
                  </div>
               </div>
            </div>
         </nav>
      </div>
   </div>
   <!-- end header -->

   <!-- end header -->
   <div class="container">
      <div class="row d-flex justify-content-center mb-5">
         <div class="col-11 bg-white rounded shadow p-3">
            <h6 class="text-center">Alur Pemesanan Dokumen pada Sistem Yandok UPN Vetaran Jakarta</h6>
         </div>
      </div>
      <div class="row d-flex justify-content-center">
         <div class="col-3 bg-white rounded shadow p-3">
            <img src="img/ilustration/order.png" class="card-img-top" alt="...">
            <hr>
            <div class="card-body">
               <p class="card-text text-justify" style="font-size: 14px;">Pilih, temukan dan tentukan jumlah dokumen
                  serta dilanjut dengan buat pesanan dengan menekan tombol <span class="text-primary">simpan</span> yang
                  dipesan pada menu <a href="pesan.html"
                     style="color: #06750F; font-weight: 600; text-decoration: none;">Pesan</a></p>
            </div>
         </div>

         <div class="col-1 align-self-center">
            <img src="img/icon/panah.png" alt="panah">
         </div>

         <div class="col-3 bg-white rounded shadow p-3">
            <img src="img/ilustration/wait.png" class="card-img-top" alt="...">
            <hr>
            <div class="card-body">
               <p class="card-text text-justify" style="font-size: 14px;">Tunggu hingga pesanan anda berstatus <span
                     class="badge-success p-1 rounded" style="font-size: 10px;">Selesai</span> pada daftar riwayat
                  pemesanan pada menu <a href="pesan.html"
                     style="color: #06750F; font-weight: 600; text-decoration: none;">Riwayat Pemesanan</a> dan untuk
                  detailnya kamu bisa membuka sub menu <span class="text-info">Detail</span></p>
            </div>
         </div>

         <div class="col-1 align-self-center">
            <img src="img/icon/panah.png" alt="panah">
         </div>
         <div class="col-3 bg-white rounded shadow p-3">
            <img src="img/ilustration/got_it.png" class="card-img-top" alt="...">
            <hr>
            <div class="card-body">
               <p class="card-text text-justify" style="font-size: 14px;">Ambil pesananmu di ULT(Unit Layanan Terpadu)
                  di kampus Cilandak sambil menunjukan kode transaksi pesanan yang ingin kamu ambil dengan cara menekan
                  tombol <span class="text-primary">Ambil pesanan</span> pada menu <a href="pesan.html"
                     style="color: #06750F; font-weight: 600; text-decoration: none;">Riwayat Pemesanan</a></p>
            </div>
         </div>


      </div>
   </div>

   <section style="background-color: #06750F; margin-top: 30%;">
      <div class="container text-center p-2 text-white">
         © 2013 - 2021 Universitas Pembangunan Nasional Veteran Jakarta | made with <img src="img/icon/coffee-cup.png"
            alt="kopi" width="24px" height="24px">
      </div>
   </section>

   <!-- JS -->
   <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
   </script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous">
   </script>

</body>

</html><?php /**PATH D:\Development\GitHub\yandok_upn-main\resources\views/alur.blade.php ENDPATH**/ ?>