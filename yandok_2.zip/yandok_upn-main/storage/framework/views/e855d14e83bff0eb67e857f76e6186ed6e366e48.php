<?php $__env->startSection('content'); ?>
<?php if($legalisir->verifikasi===1): ?>
<form action="<?php echo e(route('admin.legalisir.detail', [ 
    'legalisir' => $legalisir, 
    'status' =>  2
    ])); ?>" method="post">
<?php elseif($legalisir->verifikasi===2): ?>
<form action="<?php echo e(route('admin.legalisir.detail', [ 
    'legalisir' => $legalisir, 
    'status' =>  3
    ])); ?>" method="post" enctype="multipart/form-data">
<?php endif; ?>
<?php echo csrf_field(); ?>
<?php echo method_field("PUT"); ?>
    <div class="container mt-3 mb-5">
        <h4 class="font-weight-bolder mb-5">Pemesanan Legalisir <span style="border-left: 2px solid #000;"></span> <span
                class="font-weight-lighter pl-2 ">
                <?php if($legalisir->verifikasi===1): ?>
                    Belum Diproses
                <?php elseif($legalisir->verifikasi===2): ?>
                    Sedang Diproses
                <?php elseif($legalisir->verifikasi===3): ?>
                    Sudah Diproses
                <?php endif; ?>
            </span>
        </h4>
        <div class="row mb-5">
            <div class="col p-3 bg-white rounded shadow">
                <table class="table table-bordered" style="width: 100%;">
                    <thead class="text-white" style="background-color: #06750F;">
                        <tr>
                            <th>Kode Pesanan</th>
                            <th>Daftar Pesanan</th>
                            <th>Jumlah </th>
                            <th>Persyaratan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daftar_pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($loop->first): ?>
                                <td rowspan="3" class="text-center align-middle"><?php echo e($legalisir->id); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($key); ?></td>
                            <td class="text-center"><?php echo e($item); ?></td>

                            <?php if($loop->first): ?>
                                <?php if($legalisir->verifikasi===1): ?>
                                    <td rowspan="3" class="align-middle text-center" style="font-size: 15px;">
                                        <div class="d-flex justify-content-center">
                                            <ol type="number" class="text-left" style="font-size: 13px;">
                                                <li>Scan FC Transkrip</li>
                                                <li>Surat permohonan yang ditujukan ke dekan</li>
                                                <li>Akte kelahiran / Akte Notaris</li>
                                                <li>Foto 3x4 hitam putih</li>
                                            </ol>
                                        </div>
                                        <br>
                                        <a href="<?php echo e(route('admin.download', [ 
                                            'filePath' => 'legalisir/'.$legalisir->file
                                            ])); ?>" class="btn btn-light p-2 rounded">Download <i class="fa fa-download"></i></a>
                                    </td>
                                <?php elseif($legalisir->verifikasi===2): ?>
                                    <td class="align-middle text-center">
                                        <label for="Upload" class="btn-light p-2 rounded" id="upload" name="upload">
                                            <input type="file" name="upload">
                                        </label>
                                    </td>
                                <?php elseif($legalisir->verifikasi===3): ?>
                                    <td class="align-middle text-center">
                                        <a href="<?php echo e(route('admin.download', [ 
                                            'filePath' => 'legalisir/selesai/'.$legalisir->final_dokumen
                                            ])); ?>" class="btn btn-light p-2 rounded">Download <i class="fa fa-download"></i></a>
                                    </td>
                                <?php endif; ?>
                                
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="row">
            <div class="col bg-white rounded shadow" style="border-left: 20px solid #ecd714; border-radius: 8px;">
                <h6 class="text-left mt-2">Informasi Tambahan</h6>
                <hr style="background-color: #06750F;">
                <ul class="text-justify" style="font-size: 13px;">
                    <li>Kebutuhan : <?php echo e($legalisir->kebutuhan); ?></li>
                    <li>Permintaan Khusus : <?php echo e($legalisir->keterangan); ?></li>
                </ul>
            </div>
        </div>

        <hr>
        <?php if($legalisir->verifikasi!==3): ?>
        
            <button type="submit" class="btn btn-sm btn-success pull-right">
                Proses
            </button>
            <?php endif; ?>
            
            
    </div>
<?php if($legalisir->verifikasi!==3): ?>
</form>
<?php endif; ?>
<br/>
<br/>
<br/>
<br/>
<br/>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\GitHub\yandok_upn-main\resources\views/admin/legalisir/detail.blade.php ENDPATH**/ ?>