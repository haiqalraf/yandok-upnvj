<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col bg-white rounded shadow p-3">
            <h3>Riwayat Pesanan Anda</h3>
            <hr>
            <div class="mb-4" style="font-size: 15px;">Berikut daftar riwayat pesanan anda</div>

                <table class="table table-bordered table-md table-responsive-sm">
                    <thead class="thead-light">
                        <tr>
                            <th>Kode Pemesanan</th>
                            <th><?php echo e(strtoupper($data->id)); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Tanggal Pemesanan</td>
                            <td><?php echo e(date('d-m-y', strtotime($data->created_at))); ?></td>
                        </tr>
                        <tr>
                            <td>Detail Status</td>
                            <?php if($data->verifikasi == 1): ?>

                                <td>Menunggu peninjauan oleh pihak Dekanat</td>
                            
                            <?php elseif($data->verifikasi == 2): ?>

                                <td>Dalam proses penyiapan dokumen oleh pihak akpk</td>

                            <?php else: ?>

                                <td>Sudah Selesai, harap mengambil dokumen di loket ULT dengan menunjukan <a class="text-info" href="<?php echo e(url('/riwayat/ambil')); ?>/<?php echo e($data->id); ?>">kode pesanan</a></td>

                            <?php endif; ?>
                        </tr>
                    </tbody>
                </table>

                <table class="table table-bordered table-md table-responsive-sm">
                    <thead class="thead-light">
                        <tr>
                            <th>No.</th>
                            <th>Jenis Dokumen</th>
                            <th>Jumlah Item</th>
                            <th>Unduh Dokumen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $x = 0
                        ?>
                        <?php $__currentLoopData = $data->table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $x++
                            ?>
                            <tr>
                                <td><?php echo e($x); ?></td>
                                <td><?php echo e($table['jenis']); ?></td>
                                <td><?php echo e(intval($table['jumlah'])); ?></td>
                                <td>
                                    <?php if($data->verifikasi == 3): ?>
                                    <div class="btn btn-outline-danger"><i class="fa fa-file-pdf-o"></i> PDF</div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\GitHub\yandok_upn-main\resources\views/riwayat/detail.blade.php ENDPATH**/ ?>