   
<?php $__env->startSection('content'); ?>
<!-- Konten -->
<div class="container mb-5">
    <!-- Palet Sambutan -->
    <div class="row bg-white rounded shadow mb-5">
       <div class="col p-3">
          <h5 class="text-left" style="font-family: 'Lora', serif;">Selamat Datang,<span style="color: #0c5012;">
                <?php if(auth()->user()->is_admin===1): ?><?php echo e(auth()->user()->name); ?><?php endif; ?></span> di Sistem Layanan Dokumen Alumni UPN Veteran Jakarta</h5>
       </div>
       <img src="<?php echo e(asset('img/greeting.png')); ?>" alt="aksesoris" style="float: right; margin-bottom: 5px; opacity: 45%;"
          height="60px">
    </div>

    <!-- table Profil -->
    <div class="row">
       <div class="col bg-white p-3 rounded shadow">
          <h3>Profil Saya</h3>
          <hr><br>
          <table class="table table-borderless table-responsive-sm table-sm">
             <tr>
                <td>Nama</td>
                <td>
                   <input type="text" name="nama_alumni" class="form-control form-control-sm" placeholder="<?php echo e(auth()->user()->name); ?>"
                      readonly>
                </td>
             </tr>

             <tr>
                <td>NIP</td>
                <td>
                   <input type="text" name="nim" class="form-control form-control-sm" placeholder="<?php echo e(auth()->user()->nim); ?>" readonly>
                </td>
             </tr>

             <tr>
                <td>Email</td>
                <td>
                   <input type="email" name="email" class="form-control form-control-sm"
                      placeholder="<?php echo e(auth()->user()->email); ?>" readonly>
                </td>
             </tr>

             <tr>
                <td>Ganti Foto</td>
                <td>
                   <input type="file" name="foto" class="btn-sm" placeholder="Foto anda">
                </td>
             </tr>

             <tr>
                <td>Alamat</td>
                <td>
                   <textarea name="alamat" class="form-control form-control-sm" placeholder="Alamat"
                      style="height: 250px;">
					  <?php echo e(auth()->user()->address); ?>

                   </textarea>
                </td>
             </tr>

          </table>
          <button type="submit" class="btn btn-sm btn-success pull-right">
             <i class="fa fa-check-circle-o" aria-hidden="true"></i> Update Data Profil
          </button>
       </div>

    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\GitHub\yandok_upn-main\resources\views/admin/home.blade.php ENDPATH**/ ?>