<!doctype html>
<html lang="en">

<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
      integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

   <!-- font google -->
   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet">

   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link href="https://fonts.googleapis.com/css2?family=Lora:wght@400;500;600&display=swap" rel="stylesheet">

   <!-- font awsome -->
   <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css" />

   <!-- Local css -->
   <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

   <!-- header -->
   <div class="container-fluid mb-5 shadow bg-white">
      <div class="col">
         <nav class="navbar navbar-expand-md bg-white">
            <a id="link" class="navbar-brand" href="{{route('home')}}">
               <img id="logoku" src="img/logoUPN.png" alt="logo" height="63" width="243"
                  class="d-inline-block align-top">
            </a>
            <div class="collapse navbar-collapse">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link" href="{{route('home')}}"><i class="fa fa-home"></i></a>
                  </li>
                  <li class="nav-item ml-2">
                     <div class="dropdown ml-2">
                        <a class="nav-link dropdown-toggle active" type="button" id="dropdownMenu1"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           Pesan
                        </a>
                        <div class="dropdown-menu dropdown-menu-sm-right" aria-labelledby="dropdownMenu1">
                           <a href="{{route('legalisir.index')}}" class="dropdown-item" type="button"
                              style="font-size: small; font-weight: 600;">
                              Legalisir
                           </a>
                           <a href="surat.html" class="dropdown-item" type="button"
                              style="font-size: small; font-weight: 600;">
                              Surat Keterangan
                           </a>
                           <a href="{{route('lainnya')}}" class="dropdown-item on" type="button"
                              style="font-size: small; font-weight: 600;">
                              Lain-lainya
                           </a>
                        </div>

                     </div>
                  </li>
                  <li class="nav-item ml-2">
                     <a class="nav-link" href="{{route('riwayat')}}">Riwayat Pemesanan</a>
                  </li>
               </ul>
               <div class="dropdown ml-2">
                  <a class="nav-link dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown"
                     aria-haspopup="true" aria-expanded="false">
                     Bantuan
                  </a>
                  <div class="dropdown-menu dropdown-menu-sm-right" aria-labelledby="dropdownMenu2">
                     <a href="{{route('alur')}}" class="dropdown-item" type="button" style="font-size: small;">Alur Proses
                        Pemesanan</a>
                  </div>

               </div>
               <div class="dropdown">
                  <a style="text-decoration: none;" class="dropdown-toggle text-dark" href="#" data-toggle="dropdown">
                     <img src="img/profil.png" height="64px" width="64px"
                        style="border-radius: 50%; margin-left: 30px;">
                  </a>
                  <div class="dropdown-menu dropdown-menu-sm-right">
                     <ul class="list-unstyled p-3">
                        <li style="font-size: medium; font-weight: 500;">Albet Dwi Pangestu</li>
                        <li style="font-size: small;">18105110XX</li>
                     </ul>
                     <div class="dropdown-divider" style="width: 270px;"></div>
                     <a class="dropdown-item" href="{{route('home')}}"><i class="fa fa-sign-out"></i> Keluar</a>
                  </div>
               </div>
               <!-- Notif -->
               <div class="dropdown">
                  <a style="text-decoration: none;" class=" text-dark" href="#" data-toggle="dropdown">
                     <img src="img/icon/lonceng.png" alt="notif" class="align-self-center ml-4 mb-2">
                  </a>
                  <div class="dropdown-menu dropdown-menu-sm-right">
                     <a href="{{route('alur')}}" class="dropdown-item" type="button" style="font-size: small;">
                        <p>
                           Pesanan nomor XXX telah diverifikasi/selesai <span class="text-right">
                        </p>
                     </a>
                     <a href="{{route('alur')}}" class="dropdown-item" type="button" style="font-size: small;">
                        <p>
                           Pesanan nomor XXX telah diverifikasi/selesai <span class="text-right">
                        </p>
                     </a>
                     <a href="{{route('alur')}}" class="dropdown-item" type="button" style="font-size: small;">
                        <p>
                           Pesanan nomor XXX telah diverifikasi/selesai <span class="text-right">
                        </p>
                     </a>
                  </div>
               </div>
            </div>
         </nav>
      </div>
   </div>
   <!-- end header -->

   <div class="container mb-5">
      <div class="row">
         <div class="col bg-white rounded shadow p-3 mb-5">
            <img src="img/Info.png" alt="aksesoris" style="float: right; margin-bottom: 15px;" height="20px">
            <ul>
               <li>Isi dan lengkapi persyaratan dokumen yang ingin dipesan</li>
               <li>Pastikan dokumen yang anda ajukan sudah ditanyakan ke pihak ULT sehingga dapat dipesan</li>
               <li>Anda wajib menyertakan persyaratan dokumen untuk pengajuan dokumen yang akan dipesan.</li>
            </ul>
         </div>
      </div>
      <div class="row">
         <div class="col bg-white rounded shadow p-3">
            <h3>List Dokumen Yang ingin di ajukan</h3>
            <hr>
            <div class="mb-4" style="font-size: 15px;">Berikut Daftar Produk yang tersedia bagi anda.</div>

            <table class="table table-bordered">
               <thead class="text-white" style="background-color: #06750F;">
                  <tr>
                     <th>Jenis Dokumen</th>
                     <th style="width: 100px;">Jumlah</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <td>Legalisir Ijazah</td>
                     <td>
                        <input id="item1" type="text" class="form-control form-control-sm" style="width: 100px;"
                           value="0">
                     </td>
               </tbody>
               <tfoot>
                  <tr>
                     <td class="text-center">Total</td>
                     <td colspan="2" class="font-weight-bold text-center">
                        <div class="form-group mb-0">
                           <input type="text" id="total" class="form-control" readonly="">
                        </div>
                     </td>
                  </tr>
               </tfoot>
            </table>
            <hr>
            <div class="text-right">
               <a href="{{route('lainnya.pengajuan')}}" class="btn btn-sm btn-success mt-2 text-white">
                  <i class="fa fa-file-o"></i>
                  Buat Pengajuan Dokumen
               </a>

               <button type="button" data-target="#exampleModal" data-toggle="modal" title="Buat Pesanan"
                  class="btn btn-sm btn-success mt-2 text-white">
                  Simpan
               </button>

               <!-- Modal -->
               <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                  aria-hidden="true" data-backdrop="static" data-keyboard="false" tabindex="-1">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalLabel">Buat Pesanan</h5>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                           </button>
                        </div>
                        <div class="modal-body text-sm-left bg-light" style="font-size: 15px;">
                           Apakah anda yakin membuat pesanan dengan jumlah dokumen yang anda tentukan??<br><br>Pesanan
                           yang telah
                           dibuat tidak dapat diubah lagi jumlahnya
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-light btn-sm" data-dismiss="modal"><i
                                 class="fa fa-times"></i>
                              Close</button>
                           <a href="{{route('riwayat')}}" class="btn btn-success btn-sm"><i class="fa fa-check"></i> Ya, Saya
                              Yakin.</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>

   <section style="background-color: #06750F; margin-top: 30%;">
      <div class="container text-center p-2 text-white">
         © 2013 - 2021 Universitas Pembangunan Nasional Veteran Jakarta | made with <img src="img/icon/coffee-cup.png"
            alt="kopi" width="24px" height="24px">
      </div>
   </section>



   <!-- JS -->
   <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
   </script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous">
   </script>

   <!-- Script auto calculation -->
   <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
   <script type="text/javascript">
      $(document).ready(function () {
         $("#item1, #item2, #item3, #item4, #item5, #item6, #item7, #item8, #item9, #item10, #item11").keyup(
            function () {
               var item1 = $("#item1").val();
               var item2 = $("#item2").val();
               var item3 = $("#item3").val();
               var item4 = $("#item4").val();
               var item5 = $("#item5").val();
               var item6 = $("#item6").val();
               var item7 = $("#item7").val();
               var item8 = $("#item8").val();
               var item9 = $("#item9").val();
               var item10 = $("#item10").val();
               var item11 = $("#item11").val();
               var item12 = $("#item12").val();

               // var total = parseInt(item1) + parseInt(item2);
               var total = parseInt(item1) + parseInt(item2) + parseInt(item3) + parseInt(item4) + parseInt(
                  item5) + parseInt(item6) + parseInt(item7) + parseInt(item8) + parseInt(item9) + parseInt(
                  item10) + parseInt(item11) + parseInt(item12);
               $("#total").val(total);
            });
      });
   </script>

</body>

</html>